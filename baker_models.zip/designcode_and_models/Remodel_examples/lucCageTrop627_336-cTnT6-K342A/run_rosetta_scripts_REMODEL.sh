#!/bin/bash

switch=336-cTnT6-K342A_lucCage_0001_0006.pdb  #This pdb file is output from lucCageTrop_long_K342A_GraftSwitchMover.xml
protocol=`pwd`/Remodel_relax.xml
rosetta=/path/to/rosetta_scripts.hdf5.linuxgccrelease
output=./

$rosetta -s $switch -in:file:native $switch -beta -parser:protocol $protocol -overwrite -in::file::fullatom -out:path:all $output -num_trajectory 20 -save_top 1 -max_linear_chainbreak 0.2 -no_jumps -rg 1 -ex1 -ex2 -use_input_sc
