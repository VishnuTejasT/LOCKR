#!/bin/bash
switch=./input/lucCage.pdb 
name="sensing_domain_name"
protocol=./yourscript.xml #e.g., lucCageRBD_GraftSwitchMover.xml or lucCageRBD_MergePDB_relax.xml
rosetta=/path/to/rosetta_scripts.hdf5.linuxgccrelease
output=./output

$rosetta -s $switch -in:file:native $switch -beta -parser:protocol $protocol -overwrite -out::prefix ${name}_ -script_vars sequence=${seq} important_residues=${important_residues} -in::file::fullatom -out:path:all $output
